-- Punto 5.
select d.nombres, a.descripcion, e.nombre, ea.nota
from estudiante_asignatura ea
join asignatura a on a.id = ea.id_asignatura
join estudiante e on e.id = ea.id_estudiante
join docente d on d.id = a.id_docente
where ea.nota >= 3.1
order by ea.nota, e.nombre;

-- Punto 6.
select d.nombres, a.descripcion, e.nombre, max(ea.nota) as nota 
from estudiante_asignatura ea
join asignatura a on a.id = ea.id_asignatura
join estudiante e on e.id = ea.id_estudiante
join docente d on d.id = a.id_docente
where ea.periodo = 1;

-- See all rows.
select d.nombres, a.descripcion, e.nombre, ea.nota
from estudiante_asignatura ea
join asignatura a on a.id = ea.id_asignatura
join estudiante e on e.id = ea.id_estudiante
join docente d on d.id = a.id_docente;